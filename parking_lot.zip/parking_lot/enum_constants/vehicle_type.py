from enum import Enum


class VehicleType(Enum):
    CAR = "car"
